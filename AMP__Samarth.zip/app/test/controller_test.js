'use strict';

describe('Controller: homeController', function () {

    // load the controller's module
    beforeEach(module('ampApp'));

    var homeController,
		scope, $filter;
    // Initialize the controller and a mock scope
    beforeEach(inject(function ($controller, $rootScope) {
        scope = $rootScope.$new();

        //Injecting filter module
        inject(function (_$filter_) {
            $filter = _$filter_;
        });
        homeController = $controller('homeController', {
            $scope: scope
        });
    }));

    // Testing the number of users from JSON file
    it('Number of data in data.json file should be 6', function () {
        expect(scope.listOfMember.length).toBe(6);
    });

    // Get the full name from the json
    it('It should return the full name', function () {
        var testData = {};
        testData.firstName = "Samarth";
        testData.lastName = "Shah";
        expect(scope.getFullName(testData)).toBe(testData.firstName + " " + testData.lastName);
    });

    // Testing the filter functionality
    it('It should return the filtered list', function () {
        scope.searchValue = 's';
        var result;
        result = $filter('filter')(scope.listOfMember, scope.searchValue);
        expect(result.length).toEqual(3);
    });
});