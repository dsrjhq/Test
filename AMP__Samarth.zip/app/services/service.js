var getDataService = function ($http, $q) {
    this.fetchData = function (url) {
        var q = $q.defer();
        $http({
            method: 'Get',
            url: url,
        }).success(function successCallback(response) {
            q.resolve(response);
        }, function errorCallback(response) {
            q.reject();
        });

        return q.promise;
    }
};