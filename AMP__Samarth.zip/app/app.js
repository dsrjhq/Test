var ampAppHome = angular.module('ampApp', ['ui.router'])


/* ***** If there are partials being used, it can be configured using .config

.config(['$stateProvider', function ($stateProvider) {
    $stateProvider
        .state('home', {
        url: '/',
        templateUrl: './partials/home.html',
        controller: 'homeController'
    })           
}])

*/

	.service('getDataService', ['$http', '$q', getDataService])
    .controller('homeController', ['$scope', '$http', 'getDataService', homeController])
	.directive('peopleInfoMobileView', peopleInfoMobileView)
	.directive('peopleInfoDesktopView', peopleInfoDesktopView)