//Directive for creating  template for mobile view, to show the list of people
var peopleInfoMobileView = function () {
    return {
        scope: {
            item: '=memberInfo'
        },
        restrict: 'E',
        controller: function ($scope) {
            $scope.getFullName = function (member) {
                return member.firstName + " " + member.lastName;
            }
        },
        template: '<figure class="media dataHolder">                                                      \
					  <div class="media-left">                                                        \
						<img class="media-object" ng-src="{{item.picture}}" alt="{{item.Title}}">     \
					  </div>                                                                          \
					  <figcaption class="media-body">                                                 \
						<h3 class="media-heading">{{getFullName(item)}}</h3>                          \
						{{item.Title}}                                                                \
					  </figcaption>                                                                   \
					</figure>'
    };
};

//Directive for creating  template for desktop view, to show the list of people
var peopleInfoDesktopView = function () {
    return {
        scope: {
            item: '=memberInfo'
        },
        restrict: 'E',
        controller: function ($scope) {
            $scope.getFullName = function (member) {
                return member.firstName + " " + member.lastName;
            }
        },
        template: "<figure class='thumbnail dataHolder'>                      \
                  <img ng-src='{{item.picture}}' alt='{{item.Title}}'>    \
                  <figcaption class='caption'>                            \
	                <h3>{{getFullName(item)}}</h3>                        \
	                <p>{{item.Title}}</p>                                 \
                  </figcaption>                                           \
                </figure>"
    };
};