var homeController = function ($scope, $http, getDataService) {

    //Forming the full name from firstname and last name form the json data
    $scope.getFullName = function (member) {
        return member.firstName + " " + member.lastName;
    }

    /* To get the data from the JSON file and to call the getDataService , this app needs to be hosted on some server.
	
	I am not sure how you will test this. If you are hosting it somewhere, uncomment below service call.
	*/
    /*
	getDataService.fetchData('./data/data.json').then(function (response) {
        $scope.listOfMember = response.data;
    },
	function (data) {
	    console.log('data retrieval failed.')
	});
	*/

    // comment out below line if you are hosting this app somewhere and calling the service.
    $scope.listOfMember = [{
        "id": "1",
        "firstName": "Sean",
        "lastName": "Kerr",
        "picture": "./img/sean.png",
        "Title": "Technologiest/Developer"
    }, {
        "id": "2",
        "firstName": "Yaw",
        "lastName": "Ly",
        "picture": "./img/yaw.png",
        "Title": "Scrum Master"
    }, {
        "id": "3",
        "firstName": "Lucy",
        "lastName": "Hehir",
        "picture": "./img/lucy.png",
        "Title": "CX Designer"
    }, {
        "id": "4",
        "firstName": "Rory",
        "lastName": "Elrick",
        "picture": "./img/rory.png",
        "Title": "CX Lead"
    }, {
        "id": "5",
        "firstName": "Eric",
        "lastName": "Kwok",
        "picture": "./img/eric.png",
        "Title": "Program Manager"
    }, {
        "id": "6",
        "firstName": "Hayley",
        "lastName": "Crimmins",
        "picture": "./img/hayley.png",
        "Title": "Product Owner"
    }];
};