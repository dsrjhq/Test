var app = angular.module('app', []);
app.controller('mainCtrl', function($scope) {
    $scope.filters = {
        x: false,
        firstName: '',
        search: ''
    };
  
  
    $scope.data = [
    {
        'id': '1',
        'firstName': 'Sean',
        'lastName': 'Kerr',
        'picture': 'img/sean.png',
        'Title': 'Senior Developer'
    },
    {
        'id': '2',
        'firstName': 'Yaw',
        'lastName': 'Ly',
        'picture': 'img/yaw.png',
        'Title': 'AEM Magician'
    },
    {
        'id': '3',
        'firstName': 'Lucy',
        'lastName': 'Hehir',
        'picture': 'img/lucy.png',
        'Title': 'Scrum master'
    },
    {
        'id': '4',
        'firstName': 'Rory',
        'lastName': 'Elrick',
        'picture': 'img/rory.png',
        'Title': 'AEM Guru'
    },
    {
        'id': '5',
        'firstName': 'Eric',
        'lastName': 'Kwok',
        'picture': 'img/eric.png',
        'Title': 'Technical Lead'
    },
    {
        'id': '6',
        'firstName': 'Hayley',
        'lastName': 'Crimmins',
        'picture': 'img/hayley.png',
        'Title': 'Dev Manager'
    }
  ];
});

app.directive('filterDirective', function () {
        return {
			restrict: 'E',
            templateUrl: 'searchFilter.html'
        };
    });




