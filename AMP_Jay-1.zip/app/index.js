//Defining controller and module for the search user functionality
angular.module("myapp", [])
.controller("MyController", function($scope,$http) {
	
	//Storing list of user in $scope.listOfMember
	$scope.listOfMember = data;
	
	//Forming the full name from firstname and last name form the json data
	$scope.getFullName = function(member){
                  return member.firstName + " " + member.lastName;
     }
});

