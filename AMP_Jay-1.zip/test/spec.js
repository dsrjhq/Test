'use strict';

describe('Controller: MyController', function () {

  // load the controller's module
  beforeEach(module('myapp'));

	var MyController,
		scope,$filter;
	  // Initialize the controller and a mock scope
	  beforeEach(inject(function ($controller, $rootScope) {
		scope = $rootScope.$new();
		
		//Injecting filter module
		inject(function (_$filter_) {
		  $filter = _$filter_;
		});
		MyController = $controller('MyController', {
		  $scope: scope
		});
	  }));
	//Testing the number of users from JSON
	it('number of list in dat.js should be 6', function () {
		expect(scope.listOfMember.length).toBe(6);
	});
	
	//Getting the full name from the json
	it('it should return the full name', function () {
		var testData = {};
		testData.firstName = "Jayarnab";
		testData.lastName = "Saha";
		expect(scope.getFullName(testData)).toBe(testData.firstName + " "+ testData.lastName);
	});
	
	//Testing the filter functionality
	it('it should return the filtered list', function () {
		scope.searchValue = 's';
		var  result;
		result = $filter('filter')(scope.listOfMember,scope.searchValue);
		expect(result.length).toEqual(3);
	});
});