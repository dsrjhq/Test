//Defining controller and module for the search user functionality
var searchPeopleModule = angular.module("myapp", []);
searchPeopleModule.controller("MyController", function ($scope, $http,GetDataService) {

    //Storing list of user in $scope.listOfMember
    //$scope.listOfMember = data;

    //Forming the full name from firstname and last name form the json data
    $scope.getFullName = function (member) {
        return member.firstName + " " + member.lastName;
    }
    GetDataService.serverCall('./data.json').then(function(response) {
		$scope.listOfMember = response.data;
	},
	function(data) {
		console.log('albums retrieval failed.')
	});
});

//Service for fetching data from json file via ajax call
searchPeopleModule.service('GetDataService', function ($http,$q) {
    this.serverCall = function (url) {
       var q = $q.defer();
       $http({
            method: 'Get',
            url: url,
        }).success(function successCallback(response) {
		    q.resolve(response);
		  }, function errorCallback(response) {
			q.reject();
		  });
		 
		 return q.promise;
    }
});

//Directive for creating  template for mobile view, to show the list of people
searchPeopleModule.directive('personInfoMobileView', function () {
  return {
    scope: {
      item: '=memberInfo'
    },
    restrict: 'E',    
    controller: function ($scope) {
      $scope.getFullName = function (member) {
        return member.firstName + " " + member.lastName;
        }
    },                                                                               
    template: '<figure class="media dataHolder">                                                      \
					  <div class="media-left">                                                        \
						<img class="media-object" ng-src="{{item.picture}}" alt="{{item.Title}}">     \
					  </div>                                                                          \
					  <figcaption class="media-body">                                                 \
						<h3 class="media-heading">{{getFullName(item)}}</h3>                          \
						{{item.Title}}                                                                \
					  </figcaption>                                                                   \
					</figure>'                                                                        
    };
});

//Directive for creating  template for desktop view, to show the list of people
searchPeopleModule.directive('personInfoDesktopView', function () {
  return {
    scope: {
      item: '=memberInfo'
    },
    restrict: 'E',    
    controller: function ($scope) {
      $scope.getFullName = function (member) {
        return member.firstName + " " + member.lastName;
        }
    },                                                                               
    template: "<figure class='thumbnail dataHolder'>                      \
                  <img ng-src='{{item.picture}}' alt='{{item.Title}}'>    \
                  <figcaption class='caption'>                            \
	                <h3>{{getFullName(item)}}</h3>                        \
	                <p>{{item.Title}}</p>                                 \
                  </figcaption>                                           \
                </figure>"                                                                                                                      
    };
});