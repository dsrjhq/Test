module.exports = function(grunt) {
	grunt.initConfig({
		pkg: grunt.file.readJSON('package.json'),
		sassFiles: 'app/**/*.scss',
		sass: {
			dist: {
				files: {
					'build/style.css' : 'app/site.scss'
				}
			}
		},
		connect: {
			host: {
				port: 9876,
				open: true
			}
		},
		watch: {
			css: {
				files: '**/*.scss',
				tasks: ['sass']
			}
		}
	});
	grunt.loadNpmTasks('grunt-contrib-sass');
	grunt.loadNpmTasks('grunt-contrib-watch');
	grunt.loadNpmTasks('grunt-connect');
	grunt.loadNpmTasks('grunt-sass');
	//grunt.registerTask('build', ['watch','sass','connect:example']);
	//grunt.registerTask('default',['build']);
	//grunt.registerTask('dev', ['default', 'watch']);
	grunt.registerTask('dev', ['default','connect:host','watch']);
    grunt.registerTask('default', ['sass']);
}